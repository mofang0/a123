# FileMaster - 文件格式转换器

一款功能强大的 Android 文件格式转换应用，支持图片、视频、音频、文档、数据和压缩包等多种格式的相互转换。

## 功能特性

### 支持的格式

| 类别 | 支持格式 |
|------|---------|
| **图片** | PNG, JPG, WEBP, BMP, GIF, TIFF, ICO, AVIF, HEIC |
| **视频** | MP4, AVI, MKV, MOV, WEBM, FLV, WMV, TS |
| **音频** | MP3, AAC, WAV, FLAC, OGG, WMA, M4A, AMR, AIFF |
| **文档** | PDF, DOCX, DOC, XLSX, XLS, PPTX, PPT, TXT, RTF, CSV, HTML, MD, ODT |
| **数据** | JSON, XML, YAML, CSV |
| **压缩包** | ZIP, TAR.GZ |

### 应用功能

- 📁 **单文件转换** - 选择单个文件进行格式转换
- 📂 **批量转换** - 同时转换多个文件
- 📜 **历史记录** - 查看和管理转换历史
- ⚙️ **参数配置** - 支持质量、分辨率等参数调整
- 🌙 **深色模式** - 支持浅色/深色主题切换

## 技术架构

- **UI 框架**: Jetpack Compose + Material Design 3
- **架构模式**: MVVM + Clean Architecture
- **依赖注入**: Hilt
- **本地存储**: Room 数据库
- **导航**: Jetpack Navigation Compose
- **异步处理**: Kotlin Coroutines + Flow

## 构建 APK

### 方法 1: 使用 GitHub Actions (推荐)

1. 将项目推送到 GitHub 仓库
2. GitHub Actions 会自动构建 APK
3. 在 Actions 页面下载构建好的 APK

### 方法 2: 本地构建

```bash
# 克隆项目
git clone <repository-url>
cd FileMaster

# 构建 Debug APK
./gradlew assembleDebug

# 构建 Release APK
./gradlew assembleRelease
```

APK 输出位置:
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release.apk`

## 系统要求

- Android 8.0 (API 26) 及以上
- 存储权限用于读取和保存文件

## 项目结构

```
app/src/main/java/com/filemaster/app/
├── data/
│   ├── engine/          # 转换引擎实现
│   ├── local/           # Room 数据库
│   └── repository/      # 仓库实现
├── domain/
│   ├── model/           # 数据模型
│   ├── repository/      # 仓库接口
│   └── usecase/         # 用例
├── di/                  # 依赖注入模块
└── ui/
    ├── screens/         # 界面屏幕
    ├── theme/           # 主题配置
    └── navigation/      # 导航配置
```

## 许可证

MIT License