package com.filemaster.app.ui.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.filemaster.app.domain.model.ConversionRecord
import com.filemaster.app.domain.usecase.GetHistoryUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HistoryUiState(
    val records: List<ConversionRecord> = emptyList(),
    val isLoading: Boolean = false
)

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val getHistoryUseCase: GetHistoryUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(HistoryUiState())
    val state: StateFlow<HistoryUiState> = _state.asStateFlow()

    init {
        loadHistory()
    }

    private fun loadHistory() {
        viewModelScope.launch {
            getHistoryUseCase().collect { records ->
                _state.update { it.copy(records = records) }
            }
        }
    }

    fun search(query: String) {
        viewModelScope.launch {
            if (query.isBlank()) {
                loadHistory()
            } else {
                getHistoryUseCase.search(query).collect { records ->
                    _state.update { it.copy(records = records) }
                }
            }
        }
    }

    fun deleteRecord(id: Long) {
        viewModelScope.launch {
            // 删除记录逻辑
        }
    }
}