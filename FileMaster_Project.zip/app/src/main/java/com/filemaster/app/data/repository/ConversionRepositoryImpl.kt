package com.filemaster.app.data.repository

import com.filemaster.app.data.engine.ConverterFactory
import com.filemaster.app.data.local.dao.ConversionDao
import com.filemaster.app.data.local.entity.toDomain
import com.filemaster.app.data.local.entity.toEntity
import com.filemaster.app.domain.model.*
import com.filemaster.app.domain.repository.ConversionRepository
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConversionRepositoryImpl @Inject constructor(
    private val converterFactory: ConverterFactory,
    private val dao: ConversionDao
) : ConversionRepository {

    override suspend fun convert(
        inputFile: File,
        params: ConvertParams,
        onProgress: (Float) -> Unit
    ): ConvertResult {
        val converter = converterFactory.get(params.sourceFormat.category)
        val outputFile = generateOutputFile(inputFile, params.targetFormat)

        var finalResult: ConvertResult? = null

        converter.convert(inputFile, outputFile, params).collect { progress ->
            onProgress(progress.progress)
            if (progress.result != null) {
                finalResult = progress.result
            }
        }

        val result = finalResult ?: ConvertResult.Error("转换未完成")

        // 保存记录
        if (result is ConvertResult.Success) {
            val record = ConversionRecord(
                sourceFileName = inputFile.name,
                sourceFilePath = inputFile.absolutePath,
                sourceFormat = params.sourceFormat,
                targetFileName = outputFile.name,
                targetFilePath = outputFile.absolutePath,
                targetFormat = params.targetFormat,
                category = params.sourceFormat.category,
                sourceSize = inputFile.length(),
                outputSize = result.outputSize,
                status = ConversionStatus.SUCCESS,
                durationMs = result.durationMs
            )
            dao.insert(record.toEntity())

            if (params.deleteSource) {
                inputFile.delete()
            }
        }

        return result
    }

    override suspend fun batchConvert(
        files: List<File>,
        params: ConvertParams,
        onProgress: (Int, Int, Float) -> Unit
    ): List<ConvertResult> = coroutineScope {
        files.mapIndexed { index, file ->
            convert(file, params) { progress ->
                onProgress(index, files.size, progress)
            }
        }
    }

    override fun getHistory(): Flow<List<ConversionRecord>> =
        dao.getAll().map { entities -> entities.map { it.toDomain() } }

    override fun getHistoryByCategory(category: ConversionCategory): Flow<List<ConversionRecord>> =
        dao.getByCategory(category.name).map { entities -> entities.map { it.toDomain() } }

    override fun searchHistory(query: String): Flow<List<ConversionRecord>> =
        dao.search(query).map { entities -> entities.map { it.toDomain() } }

    override suspend fun insertRecord(record: ConversionRecord) {
        dao.insert(record.toEntity())
    }

    override suspend fun deleteRecord(id: Long) {
        dao.delete(id)
    }

    override suspend fun clearHistory() {
        dao.deleteAll()
    }

    private fun generateOutputFile(input: File, format: FileFormat): File {
        val name = input.nameWithoutExtension
        val dir = input.parentFile ?: File(System.getProperty("java.io.tmpdir"))
        return File(dir, "${name}_converted.${format.extension}")
    }
}