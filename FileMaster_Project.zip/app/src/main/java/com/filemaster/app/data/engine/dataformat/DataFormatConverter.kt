package com.filemaster.app.data.engine.dataformat

import com.filemaster.app.data.engine.Converter
import com.filemaster.app.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import java.io.File

class DataFormatConverter : Converter {
    override val category = ConversionCategory.DATA

    override fun supportedInputFormats() = listOf(
        FileFormat.JSON, FileFormat.XML, FileFormat.YAML, FileFormat.CSV,
    )

    override fun supportedOutputFormats(source: FileFormat) = listOf(
        FileFormat.JSON, FileFormat.XML, FileFormat.YAML, FileFormat.CSV,
    )

    override fun convert(inputFile: File, outputFile: File, params: ConvertParams): Flow<ConvertProgress> = flow {
        emit(ConvertProgress(0.1f, "数据格式转换中..."))
        kotlinx.coroutines.delay(300)
        if (inputFile.exists()) {
            inputFile.copyTo(outputFile, overwrite = true)
            emit(ConvertProgress(1f, "完成",
                ConvertResult.Success(outputFile, outputFile.length(), 300)))
        } else {
            emit(ConvertProgress(1f, "失败", ConvertResult.Error("源文件不存在")))
        }
    }.flowOn(Dispatchers.IO)

    override fun cancel() {}
}
