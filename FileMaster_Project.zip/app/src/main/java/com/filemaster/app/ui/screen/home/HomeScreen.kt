package com.filemaster.app.ui.screen.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.filemaster.app.domain.model.ConversionCategory
import com.filemaster.app.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FileMaster", style = MaterialTheme.typography.headlineMedium) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
        ) {
            Text(
                "万能文件转换工具",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 24.dp),
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(ConversionCategory.entries) { category ->
                    CategoryCard(
                        category = category,
                        onClick = { navController.navigate(Routes.CONVERT) },
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            OutlinedButton(
                onClick = { navController.navigate(Routes.HISTORY) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.History, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("转换历史")
            }

            Spacer(Modifier.height(8.dp))

            OutlinedButton(
                onClick = { navController.navigate(Routes.SETTINGS) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.Settings, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("设置")
            }
        }
    }
}

@Composable
fun CategoryCard(category: ConversionCategory, onClick: () -> Unit) {
    val icon = when (category) {
        ConversionCategory.IMAGE -> Icons.Default.Image
        ConversionCategory.VIDEO -> Icons.Default.Videocam
        ConversionCategory.AUDIO -> Icons.Default.Audiotrack
        ConversionCategory.DOCUMENT -> Icons.Default.Description
        ConversionCategory.DATA -> Icons.Default.Code
        ConversionCategory.ARCHIVE -> Icons.Default.FolderZip
    }
    val color = when (category) {
        ConversionCategory.IMAGE -> MaterialTheme.colorScheme.tertiaryContainer
        ConversionCategory.VIDEO -> MaterialTheme.colorScheme.secondaryContainer
        ConversionCategory.AUDIO -> MaterialTheme.colorScheme.errorContainer
        ConversionCategory.DOCUMENT -> MaterialTheme.colorScheme.primaryContainer
        ConversionCategory.DATA -> MaterialTheme.colorScheme.surfaceVariant
        ConversionCategory.ARCHIVE -> MaterialTheme.colorScheme.outlineVariant
    }

    Card(
        onClick = onClick,
        modifier = Modifier.height(120.dp),
        colors = CardDefaults.cardColors(containerColor = color),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(8.dp))
            Text(category.displayName, style = MaterialTheme.typography.titleMedium)
        }
    }
}
