package com.filemaster.app.domain.model

enum class FileFormat(val extension: String, val mimeType: String, val category: ConversionCategory) {
    // 图片
    PNG("png", "image/png", ConversionCategory.IMAGE),
    JPG("jpg", "image/jpeg", ConversionCategory.IMAGE),
    WEBP("webp", "image/webp", ConversionCategory.IMAGE),
    BMP("bmp", "image/bmp", ConversionCategory.IMAGE),
    GIF("gif", "image/gif", ConversionCategory.IMAGE),
    TIFF("tiff", "image/tiff", ConversionCategory.IMAGE),
    ICO("ico", "image/x-icon", ConversionCategory.IMAGE),
    AVIF("avif", "image/avif", ConversionCategory.IMAGE),
    HEIC("heic", "image/heic", ConversionCategory.IMAGE),

    // 视频
    MP4("mp4", "video/mp4", ConversionCategory.VIDEO),
    AVI("avi", "video/x-msvideo", ConversionCategory.VIDEO),
    MKV("mkv", "video/x-matroska", ConversionCategory.VIDEO),
    MOV("mov", "video/quicktime", ConversionCategory.VIDEO),
    WEBM("webm", "video/webm", ConversionCategory.VIDEO),
    FLV("flv", "video/x-flv", ConversionCategory.VIDEO),
    WMV("wmv", "video/x-ms-wmv", ConversionCategory.VIDEO),
    TS("ts", "video/mp2t", ConversionCategory.VIDEO),

    // 音频
    MP3("mp3", "audio/mpeg", ConversionCategory.AUDIO),
    AAC("aac", "audio/aac", ConversionCategory.AUDIO),
    WAV("wav", "audio/wav", ConversionCategory.AUDIO),
    FLAC("flac", "audio/flac", ConversionCategory.AUDIO),
    OGG("ogg", "audio/ogg", ConversionCategory.AUDIO),
    WMA("wma", "audio/x-ms-wma", ConversionCategory.AUDIO),
    M4A("m4a", "audio/mp4", ConversionCategory.AUDIO),
    AMR("amr", "audio/amr", ConversionCategory.AUDIO),
    AIFF("aiff", "audio/aiff", ConversionCategory.AUDIO),

    // 文档
    PDF("pdf", "application/pdf", ConversionCategory.DOCUMENT),
    DOCX("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ConversionCategory.DOCUMENT),
    DOC("doc", "application/msword", ConversionCategory.DOCUMENT),
    XLSX("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ConversionCategory.DOCUMENT),
    XLS("xls", "application/vnd.ms-excel", ConversionCategory.DOCUMENT),
    PPTX("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation", ConversionCategory.DOCUMENT),
    PPT("ppt", "application/vnd.ms-powerpoint", ConversionCategory.DOCUMENT),
    TXT("txt", "text/plain", ConversionCategory.DOCUMENT),
    RTF("rtf", "application/rtf", ConversionCategory.DOCUMENT),
    CSV("csv", "text/csv", ConversionCategory.DOCUMENT),
    HTML("html", "text/html", ConversionCategory.DOCUMENT),
    MD("md", "text/markdown", ConversionCategory.DOCUMENT),
    ODT("odt", "application/vnd.oasis.opendocument.text", ConversionCategory.DOCUMENT),

    // 数据
    JSON("json", "application/json", ConversionCategory.DATA),
    XML("xml", "application/xml", ConversionCategory.DATA),
    YAML("yaml", "application/x-yaml", ConversionCategory.DATA),

    // 压缩
    ZIP("zip", "application/zip", ConversionCategory.ARCHIVE),
    TAR_GZ("tar.gz", "application/gzip", ConversionCategory.ARCHIVE);

    companion object {
        fun fromExtension(ext: String): FileFormat? =
            entries.find { it.extension.equals(ext, ignoreCase = true) }
    }
}
