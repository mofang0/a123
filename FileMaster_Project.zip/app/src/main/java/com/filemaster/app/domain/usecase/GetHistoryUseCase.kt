package com.filemaster.app.domain.usecase

import com.filemaster.app.domain.model.ConversionCategory
import com.filemaster.app.domain.model.ConversionRecord
import com.filemaster.app.domain.repository.ConversionRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetHistoryUseCase @Inject constructor(
    private val repository: ConversionRepository
) {
    operator fun invoke(): Flow<List<ConversionRecord>> = repository.getHistory()

    fun byCategory(category: ConversionCategory): Flow<List<ConversionRecord>> =
        repository.getHistoryByCategory(category)

    fun search(query: String): Flow<List<ConversionRecord>> =
        repository.searchHistory(query)
}