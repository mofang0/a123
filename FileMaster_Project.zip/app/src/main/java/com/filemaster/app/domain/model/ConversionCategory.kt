package com.filemaster.app.domain.model

enum class ConversionCategory(val displayName: String, val icon: String) {
    IMAGE("图片", "🖼️"),
    VIDEO("视频", "🎬"),
    AUDIO("音频", "🎵"),
    DOCUMENT("文档", "📄"),
    DATA("数据", "📊"),
    ARCHIVE("压缩包", "📦"),
    OTHER("其他", "📎");

    companion object {
        fun fromString(value: String): ConversionCategory =
            entries.find { it.name == value } ?: OTHER
    }
}