package com.filemaster.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.filemaster.app.ui.screens.batch.BatchScreen
import com.filemaster.app.ui.screens.convert.ConvertScreen
import com.filemaster.app.ui.screens.history.HistoryScreen
import com.filemaster.app.ui.screens.home.HomeScreen
import com.filemaster.app.ui.screens.settings.SettingsScreen

sealed class Screen(val route: String, val title: String) {
    data object Home : Screen("home", "首页")
    data object Convert : Screen("convert", "转换")
    data object Batch : Screen("batch", "批量")
    data object History : Screen("history", "历史")
    data object Settings : Screen("settings", "设置")
}

@Composable
fun AppNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = modifier
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToConvert = { navController.navigate(Screen.Convert.route) },
                onNavigateToBatch = { navController.navigate(Screen.Batch.route) },
                onNavigateToHistory = { navController.navigate(Screen.History.route) }
            )
        }
        composable(Screen.Convert.route) {
            ConvertScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Batch.route) {
            BatchScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.History.route) {
            HistoryScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}