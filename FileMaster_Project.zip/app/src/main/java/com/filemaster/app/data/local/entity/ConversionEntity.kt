package com.filemaster.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.filemaster.app.domain.model.*

@Entity(tableName = "conversion_records")
data class ConversionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceFileName: String,
    val sourceFilePath: String,
    val sourceFormat: String,
    val targetFileName: String,
    val targetFilePath: String,
    val targetFormat: String,
    val category: String,
    val sourceSize: Long,
    val outputSize: Long,
    val status: String,
    val durationMs: Long,
    val timestamp: Long
)

fun ConversionEntity.toDomain(): ConversionRecord = ConversionRecord(
    id = id,
    sourceFileName = sourceFileName,
    sourceFilePath = sourceFilePath,
    sourceFormat = FileFormat.valueOf(sourceFormat),
    targetFileName = targetFileName,
    targetFilePath = targetFilePath,
    targetFormat = FileFormat.valueOf(targetFormat),
    category = ConversionCategory.fromString(category),
    sourceSize = sourceSize,
    outputSize = outputSize,
    status = ConversionStatus.valueOf(status),
    durationMs = durationMs,
    timestamp = timestamp
)

fun ConversionRecord.toEntity(): ConversionEntity = ConversionEntity(
    id = id,
    sourceFileName = sourceFileName,
    sourceFilePath = sourceFilePath,
    sourceFormat = sourceFormat.name,
    targetFileName = targetFileName,
    targetFilePath = targetFilePath,
    targetFormat = targetFormat.name,
    category = category.name,
    sourceSize = sourceSize,
    outputSize = outputSize,
    status = status.name,
    durationMs = durationMs,
    timestamp = timestamp
)