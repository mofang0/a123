package com.filemaster.app.domain.model

data class ConvertParams(
    val sourceFormat: FileFormat,
    val targetFormat: FileFormat,
    val imageQuality: Int = 85,
    val targetWidth: Int? = null,
    val targetHeight: Int? = null,
    val maintainAspectRatio: Boolean = true,
    val videoCodec: String? = null,
    val audioCodec: String? = null,
    val resolution: String? = null,
    val frameRate: Int? = null,
    val videoBitrate: String? = null,
    val audioBitrate: String? = null,
    val sampleRate: Int? = null,
    val channels: Int? = null,
    val deleteSource: Boolean = false,
)
