package com.filemaster.app.domain.model

import java.io.File

sealed class ConvertResult {
    data class Success(
        val outputFile: File,
        val durationMs: Long,
        val outputSize: Long
    ) : ConvertResult()

    data class Error(val message: String, val exception: Throwable? = null) : ConvertResult()

    data object Cancelled : ConvertResult()
}