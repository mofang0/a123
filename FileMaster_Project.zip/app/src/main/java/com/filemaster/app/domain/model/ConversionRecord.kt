package com.filemaster.app.domain.model

import java.io.File

data class ConversionRecord(
    val id: Long = 0,
    val sourceFileName: String,
    val sourceFilePath: String,
    val sourceFormat: FileFormat,
    val targetFileName: String,
    val targetFilePath: String,
    val targetFormat: FileFormat,
    val category: ConversionCategory,
    val sourceSize: Long,
    val outputSize: Long,
    val status: ConversionStatus,
    val durationMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

enum class ConversionStatus {
    SUCCESS, FAILED, CANCELLED
}