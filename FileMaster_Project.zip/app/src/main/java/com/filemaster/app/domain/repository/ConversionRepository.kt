package com.filemaster.app.domain.repository

import com.filemaster.app.domain.model.*
import kotlinx.coroutines.flow.Flow
import java.io.File

interface ConversionRepository {
    suspend fun convert(
        inputFile: File,
        params: ConvertParams,
        onProgress: (Float) -> Unit
    ): ConvertResult

    suspend fun batchConvert(
        files: List<File>,
        params: ConvertParams,
        onProgress: (Int, Int, Float) -> Unit
    ): List<ConvertResult>

    fun getHistory(): Flow<List<ConversionRecord>>
    fun getHistoryByCategory(category: ConversionCategory): Flow<List<ConversionRecord>>
    fun searchHistory(query: String): Flow<List<ConversionRecord>>
    suspend fun insertRecord(record: ConversionRecord)
    suspend fun deleteRecord(id: Long)
    suspend fun clearHistory()
}