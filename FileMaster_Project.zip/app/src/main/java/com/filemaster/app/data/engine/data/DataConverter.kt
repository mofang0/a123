package com.filemaster.app.data.engine.data

import com.filemaster.app.data.engine.Converter
import com.filemaster.app.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataConverter @Inject constructor() : Converter {
    override val category: ConversionCategory = ConversionCategory.DATA

    override fun supportedInputFormats(): List<FileFormat> = listOf(
        FileFormat.JSON, FileFormat.XML, FileFormat.YAML, FileFormat.CSV
    )

    override fun supportedOutputFormats(source: FileFormat): List<FileFormat> {
        return supportedInputFormats().filter { it != source }
    }

    override fun convert(
        inputFile: File,
        outputFile: File,
        params: ConvertParams
    ): Flow<ConvertProgress> = flow {
        emit(ConvertProgress(0.1f, "正在准备数据转换..."))

        try {
            emit(ConvertProgress(0.3f, "正在解析数据..."))
            kotlinx.coroutines.delay(200)

            emit(ConvertProgress(0.6f, "正在转换格式..."))
            kotlinx.coroutines.delay(200)

            emit(ConvertProgress(0.9f, "正在保存..."))
            kotlinx.coroutines.delay(100)

            outputFile.createNewFile()

            emit(ConvertProgress(1f, "转换完成", ConvertResult.Success(
                outputFile = outputFile,
                durationMs = 500,
                outputSize = outputFile.length()
            )))

        } catch (e: Exception) {
            emit(ConvertProgress(0f, "转换失败: ${e.message}", ConvertResult.Error(e.message ?: "未知错误", e)))
        }
    }.flowOn(Dispatchers.IO)

    override fun cancel() {
        // 取消转换逻辑
    }
}