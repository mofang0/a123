package com.filemaster.app.data.engine

import com.filemaster.app.domain.model.*
import kotlinx.coroutines.flow.Flow
import java.io.File

interface Converter {
    val category: ConversionCategory
    fun supportedInputFormats(): List<FileFormat>
    fun supportedOutputFormats(source: FileFormat): List<FileFormat>
    fun convert(inputFile: File, outputFile: File, params: ConvertParams): Flow<ConvertProgress>
    fun cancel()
}
