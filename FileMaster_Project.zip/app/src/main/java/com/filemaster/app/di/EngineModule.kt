package com.filemaster.app.di

import com.filemaster.app.data.engine.Converter
import com.filemaster.app.data.engine.archive.ArchiveConverter
import com.filemaster.app.data.engine.audio.AudioConverter
import com.filemaster.app.data.engine.data.DataConverter
import com.filemaster.app.data.engine.document.DocumentConverter
import com.filemaster.app.data.engine.image.ImageConverter
import com.filemaster.app.data.engine.video.VideoConverter
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet

@Module
@InstallIn(SingletonComponent::class)
abstract class EngineModule {

    @Binds
    @IntoSet
    abstract fun bindImageConverter(impl: ImageConverter): Converter

    @Binds
    @IntoSet
    abstract fun bindVideoConverter(impl: VideoConverter): Converter

    @Binds
    @IntoSet
    abstract fun bindAudioConverter(impl: AudioConverter): Converter

    @Binds
    @IntoSet
    abstract fun bindDocumentConverter(impl: DocumentConverter): Converter

    @Binds
    @IntoSet
    abstract fun bindDataConverter(impl: DataConverter): Converter

    @Binds
    @IntoSet
    abstract fun bindArchiveConverter(impl: ArchiveConverter): Converter
}