package com.filemaster.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.filemaster.app.data.local.dao.ConversionDao
import com.filemaster.app.data.local.entity.ConversionEntity

@Database(
    entities = [ConversionEntity::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversionDao(): ConversionDao
}