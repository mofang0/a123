package com.filemaster.app.domain.model

data class ConvertProgress(
    val progress: Float = 0f,
    val message: String = "",
    val result: ConvertResult? = null
)