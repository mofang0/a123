package com.filemaster.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FileMasterApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}