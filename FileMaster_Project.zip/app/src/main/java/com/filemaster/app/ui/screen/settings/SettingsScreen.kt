package com.filemaster.app.ui.screen.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("设置") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
        ) {
            Text("FileMaster v1.0.0", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text("万能文件转换工具", style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            Text("支持的格式:", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            Text("图片: PNG, JPG, WEBP, BMP, GIF, TIFF, ICO, AVIF, HEIC",
                style = MaterialTheme.typography.bodySmall)
            Text("视频: MP4, AVI, MKV, MOV, WEBM, FLV, WMV, TS",
                style = MaterialTheme.typography.bodySmall)
            Text("音频: MP3, AAC, WAV, FLAC, OGG, WMA, M4A, AMR, AIFF",
                style = MaterialTheme.typography.bodySmall)
            Text("文档: PDF, DOCX, DOC, XLSX, XLS, PPTX, PPT, TXT, RTF, CSV, HTML, MD, ODT",
                style = MaterialTheme.typography.bodySmall)
            Text("数据: JSON, XML, YAML",
                style = MaterialTheme.typography.bodySmall)
            Text("压缩: ZIP, TAR.GZ",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
