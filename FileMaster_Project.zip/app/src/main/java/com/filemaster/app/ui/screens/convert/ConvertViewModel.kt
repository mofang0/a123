package com.filemaster.app.ui.screens.convert

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.filemaster.app.domain.model.*
import com.filemaster.app.domain.usecase.ConvertFileUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class ConvertUiState(
    val selectedFile: File? = null,
    val sourceFormat: FileFormat? = null,
    val targetFormat: FileFormat? = null,
    val availableTargets: List<FileFormat> = emptyList(),
    val params: ConvertParams = ConvertParams(),
    val isConverting: Boolean = false,
    val progress: Float = 0f,
    val statusMessage: String = "",
    val result: ConvertResult? = null
)

@HiltViewModel
class ConvertViewModel @Inject constructor(
    private val convertFileUseCase: ConvertFileUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(ConvertUiState())
    val state: StateFlow<ConvertUiState> = _state.asStateFlow()

    fun selectFile(file: File) {
        val format = FileFormat.fromExtension(file.extension)
        val availableTargets = convertFileUseCase.getAvailableTargets(format)

        _state.update {
            it.copy(
                selectedFile = file,
                sourceFormat = format,
                targetFormat = null,
                availableTargets = availableTargets,
                params = ConvertParams(sourceFormat = format)
            )
        }
    }

    fun selectTargetFormat(format: FileFormat) {
        _state.update {
            it.copy(
                targetFormat = format,
                params = it.params.copy(targetFormat = format)
            )
        }
    }

    fun updateImageQuality(quality: Int) {
        _state.update {
            it.copy(
                params = it.params.copy(imageQuality = quality)
            )
        }
    }

    fun startConvert() {
        val currentState = _state.value
        val file = currentState.selectedFile ?: return
        val params = currentState.params

        viewModelScope.launch {
            _state.update { it.copy(isConverting = true, progress = 0f, result = null) }

            convertFileUseCase(file, params) { progress ->
                _state.update {
                    it.copy(
                        progress = progress,
                        statusMessage = "转换中... ${(progress * 100).toInt()}%"
                    )
                }
            }.collect { result ->
                _state.update {
                    it.copy(
                        isConverting = false,
                        result = result,
                        statusMessage = ""
                    )
                }
            }
        }
    }
}