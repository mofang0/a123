package com.filemaster.app.data.local.dao

import androidx.room.*
import com.filemaster.app.data.local.entity.ConversionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversionDao {
    @Query("SELECT * FROM conversion_records ORDER BY timestamp DESC")
    fun getAll(): Flow<List<ConversionEntity>>

    @Query("SELECT * FROM conversion_records WHERE category = :category ORDER BY timestamp DESC")
    fun getByCategory(category: String): Flow<List<ConversionEntity>>

    @Query("""
        SELECT * FROM conversion_records 
        WHERE sourceFileName LIKE '%' || :query || '%' 
        OR targetFileName LIKE '%' || :query || '%'
        ORDER BY timestamp DESC
    """)
    fun search(query: String): Flow<List<ConversionEntity>>

    @Insert
    suspend fun insert(record: ConversionEntity): Long

    @Delete
    suspend fun delete(record: ConversionEntity)

    @Query("DELETE FROM conversion_records WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM conversion_records")
    suspend fun deleteAll()
}