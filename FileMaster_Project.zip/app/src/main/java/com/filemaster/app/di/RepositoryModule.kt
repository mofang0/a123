package com.filemaster.app.di

import com.filemaster.app.data.repository.ConversionRepositoryImpl
import com.filemaster.app.domain.repository.ConversionRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindConversionRepository(
        impl: ConversionRepositoryImpl
    ): ConversionRepository
}