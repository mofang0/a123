package com.filemaster.app.data.engine.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.filemaster.app.data.engine.Converter
import com.filemaster.app.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ImageConverter @Inject constructor() : Converter {
    override val category: ConversionCategory = ConversionCategory.IMAGE

    override fun supportedInputFormats(): List<FileFormat> = listOf(
        FileFormat.PNG, FileFormat.JPG, FileFormat.WEBP,
        FileFormat.BMP, FileFormat.GIF, FileFormat.TIFF,
        FileFormat.ICO, FileFormat.AVIF, FileFormat.HEIC
    )

    override fun supportedOutputFormats(source: FileFormat): List<FileFormat> {
        return supportedInputFormats().filter { it != source }
    }

    override fun convert(
        inputFile: File,
        outputFile: File,
        params: ConvertParams
    ): Flow<ConvertProgress> = flow {
        emit(ConvertProgress(0.1f, "正在加载图片..."))

        try {
            val bitmap = BitmapFactory.decodeFile(inputFile.absolutePath)
                ?: throw IllegalArgumentException("无法解码图片文件")

            emit(ConvertProgress(0.3f, "正在处理..."))

            val processedBitmap = if (params.targetWidth != null || params.targetHeight != null) {
                resizeBitmap(bitmap, params.targetWidth, params.targetHeight, params.maintainAspectRatio)
            } else {
                bitmap
            }

            emit(ConvertProgress(0.6f, "正在保存..."))

            val success = saveBitmap(processedBitmap, outputFile, params.targetFormat, params.imageQuality)

            if (success) {
                emit(ConvertProgress(1f, "转换完成", ConvertResult.Success(
                    outputFile = outputFile,
                    durationMs = 0,
                    outputSize = outputFile.length()
                )))
            } else {
                emit(ConvertProgress(0f, "保存失败", ConvertResult.Error("保存图片失败")))
            }

            if (processedBitmap != bitmap) {
                processedBitmap.recycle()
            }
            bitmap.recycle()

        } catch (e: Exception) {
            emit(ConvertProgress(0f, "转换失败: ${e.message}", ConvertResult.Error(e.message ?: "未知错误", e)))
        }
    }.flowOn(Dispatchers.IO)

    override fun cancel() {
        // 图片转换是同步操作，取消逻辑在协程中处理
    }

    private fun resizeBitmap(
        source: Bitmap,
        targetWidth: Int?,
        targetHeight: Int?,
        maintainAspectRatio: Boolean
    ): Bitmap {
        val width = targetWidth ?: source.width
        val height = targetHeight ?: source.height

        return if (maintainAspectRatio) {
            val ratio = minOf(
                width.toFloat() / source.width,
                height.toFloat() / source.height
            )
            val newWidth = (source.width * ratio).toInt()
            val newHeight = (source.height * ratio).toInt()
            Bitmap.createScaledBitmap(source, newWidth, newHeight, true)
        } else {
            Bitmap.createScaledBitmap(source, width, height, true)
        }
    }

    private fun saveBitmap(bitmap: Bitmap, file: File, format: FileFormat, quality: Int): Boolean {
        return try {
            FileOutputStream(file).use { out ->
                val compressFormat = when (format) {
                    FileFormat.PNG -> Bitmap.CompressFormat.PNG
                    FileFormat.JPG -> Bitmap.CompressFormat.JPEG
                    FileFormat.WEBP -> Bitmap.CompressFormat.WEBP
                    else -> Bitmap.CompressFormat.PNG
                }
                bitmap.compress(compressFormat, quality, out)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}