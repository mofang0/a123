package com.filemaster.app.data.engine

import com.filemaster.app.domain.model.ConversionCategory
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConverterFactory @Inject constructor(
    private val converters: Set<@JvmSuppressWildcards Converter>
) {
    fun get(category: ConversionCategory): Converter {
        return converters.find { it.category == category }
            ?: throw IllegalArgumentException("No converter found for category: $category")
    }
}