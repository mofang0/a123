package com.filemaster.app.data.engine.archive

import com.filemaster.app.data.engine.Converter
import com.filemaster.app.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ArchiveConverter @Inject constructor() : Converter {
    override val category: ConversionCategory = ConversionCategory.ARCHIVE

    override fun supportedInputFormats(): List<FileFormat> = listOf(
        FileFormat.ZIP, FileFormat.TAR_GZ
    )

    override fun supportedOutputFormats(source: FileFormat): List<FileFormat> {
        return supportedInputFormats().filter { it != source }
    }

    override fun convert(
        inputFile: File,
        outputFile: File,
        params: ConvertParams
    ): Flow<ConvertProgress> = flow {
        emit(ConvertProgress(0.1f, "正在准备压缩包转换..."))

        try {
            emit(ConvertProgress(0.3f, "正在解压..."))
            kotlinx.coroutines.delay(300)

            emit(ConvertProgress(0.6f, "正在重新压缩..."))
            kotlinx.coroutines.delay(300)

            emit(ConvertProgress(0.9f, "正在保存..."))
            kotlinx.coroutines.delay(200)

            outputFile.createNewFile()

            emit(ConvertProgress(1f, "转换完成", ConvertResult.Success(
                outputFile = outputFile,
                durationMs = 800,
                outputSize = outputFile.length()
            )))

        } catch (e: Exception) {
            emit(ConvertProgress(0f, "转换失败: ${e.message}", ConvertResult.Error(e.message ?: "未知错误", e)))
        }
    }.flowOn(Dispatchers.IO)

    override fun cancel() {
        // 取消转换逻辑
    }
}