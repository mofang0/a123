package com.filemaster.app.ui.screens.batch

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.filemaster.app.domain.model.ConvertParams
import com.filemaster.app.domain.model.ConvertResult
import com.filemaster.app.domain.model.FileFormat
import com.filemaster.app.domain.usecase.ConvertFileUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class BatchUiState(
    val files: List<File> = emptyList(),
    val targetFormat: FileFormat? = null,
    val isConverting: Boolean = false,
    val currentIndex: Int = 0,
    val totalProgress: Float = 0f,
    val results: List<ConvertResult> = emptyList()
)

@HiltViewModel
class BatchViewModel @Inject constructor(
    private val convertFileUseCase: ConvertFileUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(BatchUiState())
    val state: StateFlow<BatchUiState> = _state.asStateFlow()

    fun addFiles() {
        // 模拟添加文件
        _state.update {
            it.copy(files = it.files + File("/path/to/file${it.files.size + 1}.txt"))
        }
    }

    fun removeFile(file: File) {
        _state.update {
            it.copy(files = it.files - file)
        }
    }

    fun startBatchConvert() {
        val files = _state.value.files
        if (files.isEmpty()) return

        viewModelScope.launch {
            _state.update { it.copy(isConverting = true, currentIndex = 0) }

            val results = mutableListOf<ConvertResult>()

            files.forEachIndexed { index, file ->
                _state.update { it.copy(currentIndex = index + 1) }

                val format = FileFormat.fromExtension(file.extension)
                val targetFormat = convertFileUseCase.getAvailableTargets(format).firstOrNull()
                    ?: return@forEachIndexed

                val params = ConvertParams(
                    sourceFormat = format,
                    targetFormat = targetFormat
                )

                convertFileUseCase(file, params) { progress ->
                    val totalProgress = (index + progress) / files.size
                    _state.update { it.copy(totalProgress = totalProgress) }
                }.collect { result ->
                    results.add(result)
                }
            }

            _state.update {
                it.copy(
                    isConverting = false,
                    results = results
                )
            }
        }
    }
}