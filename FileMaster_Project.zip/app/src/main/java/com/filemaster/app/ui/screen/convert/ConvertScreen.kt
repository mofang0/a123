package com.filemaster.app.ui.screen.convert

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.filemaster.app.domain.model.*
import com.filemaster.app.util.FileUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConvertScreen(navController: NavController, viewModel: ConvertViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val pickFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val file = FileUtils.uriToFile(context, it)
            if (file != null) viewModel.selectFile(file)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("文件转换") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Card(
                onClick = { pickFileLauncher.launch("*/*") },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        if (state.selectedFile != null) Icons.Default.InsertDriveFile
                        else Icons.Default.CloudUpload,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        state.selectedFile?.name ?: "点击选择文件",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    if (state.sourceFormat != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "格式: ${state.sourceFormat!!.extension.uppercase()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            if (state.selectedFile != null) {
                Spacer(Modifier.height(16.dp))

                Text("选择目标格式:", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.availableTargets.forEach { format ->
                        FilterChip(
                            selected = state.targetFormat == format,
                            onClick = { viewModel.selectTargetFormat(format) },
                            label = { Text(format.extension.uppercase()) },
                        )
                    }
                }

                if (state.sourceFormat?.category == ConversionCategory.IMAGE) {
                    Spacer(Modifier.height(16.dp))
                    Text("输出质量: ${state.params.imageQuality}%", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = state.params.imageQuality.toFloat(),
                        onValueChange = { viewModel.updateQuality(it.toInt()) },
                        valueRange = 10f..100f,
                    )
                }

                Spacer(Modifier.height(24.dp))

                if (state.isConverting) {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(state.statusMessage, style = MaterialTheme.typography.bodySmall)
                } else {
                    Button(
                        onClick = { viewModel.startConvert() },
                        enabled = state.selectedFile != null && state.targetFormat != null,
                        modifier = Modifier.fillMaxWidth(0.8f),
                    ) {
                        Icon(Icons.Default.Transform, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("开始转换", style = MaterialTheme.typography.titleMedium)
                    }
                }

                state.result?.let { result ->
                    Spacer(Modifier.height(16.dp))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = when (result) {
                                is ConvertResult.Success -> MaterialTheme.colorScheme.primaryContainer
                                is ConvertResult.Error -> MaterialTheme.colorScheme.errorContainer
                                ConvertResult.Cancelled -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            when (result) {
                                is ConvertResult.Success -> {
                                    Text("转换成功!", style = MaterialTheme.typography.titleMedium)
                                    Spacer(Modifier.height(4.dp))
                                    Text("输出: ${result.outputFile.name}", style = MaterialTheme.typography.bodySmall)
                                    Text("大小: ${result.outputSize / 1024} KB", style = MaterialTheme.typography.bodySmall)
                                    Text("耗时: ${result.durationMs} ms", style = MaterialTheme.typography.bodySmall)
                                }
                                is ConvertResult.Error -> {
                                    Text("转换失败: ${result.message}", style = MaterialTheme.typography.bodySmall)
                                }
                                ConvertResult.Cancelled -> {
                                    Text("已取消", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { viewModel.reset(); navController.popBackStack() }) {
                    Text("返回首页")
                }
            }
        }
    }
}
