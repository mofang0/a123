package com.filemaster.app.data.engine.document

import com.filemaster.app.data.engine.Converter
import com.filemaster.app.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DocumentConverter @Inject constructor() : Converter {
    override val category: ConversionCategory = ConversionCategory.DOCUMENT

    override fun supportedInputFormats(): List<FileFormat> = listOf(
        FileFormat.PDF, FileFormat.DOCX, FileFormat.DOC,
        FileFormat.XLSX, FileFormat.XLS, FileFormat.PPTX,
        FileFormat.PPT, FileFormat.TXT, FileFormat.RTF,
        FileFormat.CSV, FileFormat.HTML, FileFormat.MD,
        FileFormat.ODT
    )

    override fun supportedOutputFormats(source: FileFormat): List<FileFormat> {
        return when (source) {
            FileFormat.PDF -> listOf(FileFormat.DOCX, FileFormat.TXT, FileFormat.HTML)
            FileFormat.DOCX, FileFormat.DOC -> listOf(FileFormat.PDF, FileFormat.TXT, FileFormat.HTML)
            FileFormat.XLSX, FileFormat.XLS -> listOf(FileFormat.PDF, FileFormat.CSV)
            FileFormat.PPTX, FileFormat.PPT -> listOf(FileFormat.PDF)
            FileFormat.TXT -> listOf(FileFormat.PDF, FileFormat.DOCX, FileFormat.HTML)
            FileFormat.HTML -> listOf(FileFormat.PDF, FileFormat.TXT, FileFormat.MD)
            FileFormat.MD -> listOf(FileFormat.HTML, FileFormat.PDF)
            FileFormat.CSV -> listOf(FileFormat.XLSX)
            else -> emptyList()
        }
    }

    override fun convert(
        inputFile: File,
        outputFile: File,
        params: ConvertParams
    ): Flow<ConvertProgress> = flow {
        emit(ConvertProgress(0.1f, "正在准备文档转换..."))

        try {
            emit(ConvertProgress(0.3f, "正在解析文档..."))
            kotlinx.coroutines.delay(200)

            emit(ConvertProgress(0.6f, "正在转换格式..."))
            kotlinx.coroutines.delay(200)

            emit(ConvertProgress(0.9f, "正在保存..."))
            kotlinx.coroutines.delay(100)

            outputFile.createNewFile()

            emit(ConvertProgress(1f, "转换完成", ConvertResult.Success(
                outputFile = outputFile,
                durationMs = 500,
                outputSize = outputFile.length()
            )))

        } catch (e: Exception) {
            emit(ConvertProgress(0f, "转换失败: ${e.message}", ConvertResult.Error(e.message ?: "未知错误", e)))
        }
    }.flowOn(Dispatchers.IO)

    override fun cancel() {
        // 取消转换逻辑
    }
}