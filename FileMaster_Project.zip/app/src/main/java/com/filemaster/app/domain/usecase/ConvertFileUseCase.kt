package com.filemaster.app.domain.usecase

import com.filemaster.app.domain.model.*
import com.filemaster.app.domain.repository.ConversionRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.File
import javax.inject.Inject

class ConvertFileUseCase @Inject constructor(
    private val repository: ConversionRepository
) {
    suspend operator fun invoke(
        inputFile: File,
        params: ConvertParams,
        onProgress: (Float) -> Unit
    ): Flow<ConvertResult> = flow {
        val result = repository.convert(inputFile, params, onProgress)
        emit(result)
    }

    fun getAvailableTargets(sourceFormat: FileFormat): List<FileFormat> {
        return when (sourceFormat.category) {
            ConversionCategory.IMAGE -> listOf(
                FileFormat.PNG, FileFormat.JPG, FileFormat.WEBP,
                FileFormat.BMP, FileFormat.GIF, FileFormat.TIFF,
                FileFormat.ICO, FileFormat.AVIF, FileFormat.HEIC
            )
            ConversionCategory.VIDEO -> listOf(
                FileFormat.MP4, FileFormat.AVI, FileFormat.MKV,
                FileFormat.MOV, FileFormat.WEBM, FileFormat.FLV,
                FileFormat.WMV, FileFormat.TS
            )
            ConversionCategory.AUDIO -> listOf(
                FileFormat.MP3, FileFormat.AAC, FileFormat.WAV,
                FileFormat.FLAC, FileFormat.OGG, FileFormat.WMA,
                FileFormat.M4A, FileFormat.AMR, FileFormat.AIFF
            )
            ConversionCategory.DOCUMENT -> listOf(
                FileFormat.PDF, FileFormat.DOCX, FileFormat.DOC,
                FileFormat.XLSX, FileFormat.XLS, FileFormat.PPTX,
                FileFormat.PPT, FileFormat.TXT, FileFormat.RTF,
                FileFormat.CSV, FileFormat.HTML, FileFormat.MD,
                FileFormat.ODT
            )
            ConversionCategory.DATA -> listOf(
                FileFormat.JSON, FileFormat.XML, FileFormat.YAML,
                FileFormat.CSV
            )
            ConversionCategory.ARCHIVE -> listOf(
                FileFormat.ZIP, FileFormat.TAR_GZ
            )
            else -> emptyList()
        }.filter { it != sourceFormat }
    }
}