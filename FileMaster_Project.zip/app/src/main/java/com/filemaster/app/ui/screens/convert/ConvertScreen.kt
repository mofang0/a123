package com.filemaster.app.ui.screens.convert

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.filemaster.app.domain.model.ConversionCategory
import com.filemaster.app.domain.model.ConvertResult
import com.filemaster.app.domain.model.FileFormat
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConvertScreen(
    viewModel: ConvertViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val pickFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            val file = File(it.path ?: return@let)
            viewModel.selectFile(file)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("文件转换") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 文件选择
            FilePickerCard(
                selectedFile = state.selectedFile,
                sourceFormat = state.sourceFormat,
                onClick = { pickFileLauncher.launch("*/*") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 目标格式选择
            if (state.sourceFormat != null) {
                FormatSelector(
                    formats = state.availableTargets,
                    selected = state.targetFormat,
                    onSelect = viewModel::selectTargetFormat
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 参数配置
            state.sourceFormat?.category?.let { category ->
                when (category) {
                    ConversionCategory.IMAGE -> ImageParamsPanel(
                        quality = state.params.imageQuality,
                        onQualityChange = { viewModel.updateImageQuality(it) }
                    )
                    else -> {}
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 转换按钮或进度
            if (state.isConverting) {
                ConvertProgressBar(
                    progress = state.progress,
                    message = state.statusMessage
                )
            } else {
                Button(
                    onClick = viewModel::startConvert,
                    enabled = state.selectedFile != null && state.targetFormat != null,
                    modifier = Modifier.fillMaxWidth(0.8f)
                ) {
                    Text("开始转换", fontSize = 18.sp)
                }
            }

            // 结果展示
            state.result?.let { result ->
                Spacer(modifier = Modifier.height(16.dp))
                ResultCard(result = result)
            }
        }
    }
}

@Composable
fun FilePickerCard(
    selectedFile: File?,
    sourceFormat: FileFormat?,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.FolderOpen,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            if (selectedFile != null) {
                Text(
                    text = selectedFile.name,
                    style = MaterialTheme.typography.titleMedium
                )
                sourceFormat?.let {
                    Text(
                        text = "格式: ${it.extension.uppercase()}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    text = "点击选择文件",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

@Composable
fun FormatSelector(
    formats: List<FileFormat>,
    selected: FileFormat?,
    onSelect: (FileFormat) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "选择目标格式",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            formats.forEach { format ->
                FilterChip(
                    selected = selected == format,
                    onClick = { onSelect(format) },
                    label = { Text(format.extension.uppercase()) }
                )
            }
        }
    }
}

@Composable
fun ImageParamsPanel(
    quality: Int,
    onQualityChange: (Int) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "图片参数",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text("质量: $quality%")
            Slider(
                value = quality.toFloat(),
                onValueChange = { onQualityChange(it.toInt()) },
                valueRange = 10f..100f,
                steps = 8
            )
        }
    }
}

@Composable
fun ConvertProgressBar(
    progress: Float,
    message: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ResultCard(result: ConvertResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (result) {
                is ConvertResult.Success -> MaterialTheme.colorScheme.primaryContainer
                is ConvertResult.Error -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            when (result) {
                is ConvertResult.Success -> {
                    Text(
                        "转换成功!",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        "输出文件: ${result.outputFile.name}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is ConvertResult.Error -> {
                    Text(
                        "转换失败",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Text(
                        result.message,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                ConvertResult.Cancelled -> {
                    Text("已取消", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}